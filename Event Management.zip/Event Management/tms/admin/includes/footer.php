<div class="copyrights">
	 <p>EMS. All Rights Reserved |  <a href="#">EMS</a> </p>
</div>	

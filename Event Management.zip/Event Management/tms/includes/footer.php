



<!--- /footer-top ---->
<!---copy-right ---->
<div class="copy-right">
	<div class="container">
	
		<div class="footer-social-icons wow fadeInDown animated animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInDown;">
			<ul>
				<li><a class="facebook" href="https://www.facebook.com/"><span>Facebook</span></a></li>
				<li><a class="googleplus" href="https://www.google.com/webhp?authuser=1"><span>Google+</span></a></li>
				
		</div>
		<p class="wow zoomIn animated animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: zoomIn;"> EMS . All Rights Reserved </p>
	</div>
</div>